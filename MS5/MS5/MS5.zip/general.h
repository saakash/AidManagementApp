/* Name: Aakash Shrestha
Student ID: 140051160
OOP244 SDD
Final Project: Milestone 5
Date: 2017 July 25
*/

#ifndef SICT_GENERAL_H__
#define SICT_GENERAL_H__

//define statememts
#define TAX 0.13
#define MAX_SKU_LEN 7
#define DISPLAY_LINES 10
#define MIN_YEAR 2000
#define MAX_YEAR 2030
#define MAX_NO_RECS 2000
#endif